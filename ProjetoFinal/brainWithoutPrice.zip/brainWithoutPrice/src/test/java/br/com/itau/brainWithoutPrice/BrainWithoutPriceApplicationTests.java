package br.com.itau.brainWithoutPrice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BrainWithoutPriceApplicationTests {

	@Test
	void contextLoads() {
	}

}
